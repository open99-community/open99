const fs = require("fs");
const https = require("https");

/**
 * Downloads a file over https
 * @param  {URL} url the url where the file to download is located
 * @param  {fs.PathLike} path the location and filename to save the file to
 * @returns {void}
 * @example
 * downloadFile("https://nandertga.ddns.net/w96-packages/fsbuilder.js", "./fsbuilder.js");
 */
async function downloadFile(url, path) {
    https.get(url, (res) => {
        if (res.statusCode == 404) return;
        // Image will be stored at this path
        const filePath = fs.createWriteStream(path);
        res.pipe(filePath);
        filePath.on("finish", () => {
            filePath.close();
            console.log(`Download of ${path} completed`);
        });
    }).on("error", (e) => {
        console.error(e);
    });
}
exports.downloadFile = downloadFile;

/**
 * Downloads a file over https
 * @param  {URL} url the url where the file to download is located
 * @param  {fs.PathLike} path the location and filename to save the file to
 * @returns {Promise<void>}
 * @example
 * await downloadFile("https://nandertga.ddns.net/w96-packages/fsbuilder.js", "./fsbuilder.js");
 */
async function downloadFileAsync(url, path) {
    return new Promise((resolve, reject) => {
        https.get(url, (res) => {
            if (res.statusCode == 404) reject();
            // Image will be stored at this path
            const filePath = fs.createWriteStream(path);
            res.pipe(filePath);
            filePath.on("finish", () => {
                filePath.close();
                console.log(`Download of ${path} completed`);
                resolve();
            });
        }).on("error", (e) => {
            console.error(e);
            reject();
        });
    });
}
exports.downloadFileAsync = downloadFileAsync;