first time run download.bat, after that you can run start server.bat anytime you wish to start your local copy of w96 on port 3000
DO NOT SHARE YOUR LOCAL COPY WITH ANYONE!!