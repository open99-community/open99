/**
 * Express server
 * when a 404 occurs, it will download the file from windows96.net
 */
const express = require("express");
const app = express();
const port = 3000;
const { downloadFileAsync } = require("./downloadFile");
const path = require("path");

app.use(express.static(__dirname + "/", { dotfiles: "allow" }));

// if the file isn't found, then try to download it from windows96.net
app.use(function(req, res, next) {
    res.status(404);
    console.log(req.url);
    try {
        downloadFileAsync(`https://windows96.net${req.url}`, `.${req.url}`).then(() => {
            try{
                console.log(path.resolve(`.${req.url}`));
                res.sendFile(path.resolve(`.${req.url}`));
            } catch {
                res.send("wait is this code even reachable?");
            }
        });
        
    } catch {
        res.type("txt").send("Not found");
    }
});
app.listen(port, () => console.log(`Example app listening on port ${port}!`));