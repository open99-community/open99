const fs = require("fs");
const https = require("https");
const path = require("path");
const { downloadFile } = require("./downloadFile");
const rofs = JSON.parse(fs.readFileSync(process.argv[2]));

// first iterate through all the directories and make sure they exist
Object.entries(rofs).forEach(([ key, value ]) => {
    if (value.type == 1) {
        console.log(`make dir ./${key}`);
        // could this cause a bug which occurs when there's a directory and a file with the same name? //TODO I should do more checks really
        if (!fs.existsSync(`./${key}`)) {
            fs.mkdirSync(`./${key}`);
        }
    }
});

// then download all the files
Object.entries(rofs).forEach(([ key, value ]) => {
    if (value.type == 0) downloadFile(`https://windows96.net${key}`, `./${key}`);
});